<div class="container">
  <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#">Keranjang</a>
          </li>
          <li class="breadcrumb-item">
            <a href="#">Alamat</a>
          </li>
          <li class="breadcrumb-item"> <a href="#">Pembayaran</a></li>
          <li class="breadcrumb-item active" aria-current="page">Selesai</li>
          </li>
        </ol>
      </nav>
	<div class="alert alert-success" role="alert">
  <div class="text-center">
  	<img src="https://www.pngall.com/wp-content/uploads/5/Checklist-Logo.png" style="width:120px; height: 120px;">
    <h4> Selamat, Pesanan anda Berhasil di Proses!!</h4>
  </div>
</div>
</div>